import React from 'react';
import { Briefcase, FileText } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Layout from '../components/Layout/Layout';
import TaskCard from '../components/Tasks/TaskCard';
import { formatDate } from '../utils/format';

const ProfilePage: React.FC = () => {
  const { currentUser, getTasksForUser, getBidsForUser, getTaskById } = useAppContext();
  
  if (!currentUser) {
    return (
      <Layout>
        <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900">Please sign in to view your profile</h2>
        </div>
      </Layout>
    );
  }
  
  const userTasks = getTasksForUser(currentUser.id);
  const userBids = getBidsForUser(currentUser.id);
  
  return (
    <Layout>
      <div className="bg-gradient-to-r from-blue-900 to-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center">
            <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-6">
              <img 
                src={currentUser.profilePicture || 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg'} 
                alt={currentUser.name}
                className="h-32 w-32 rounded-full object-cover border-4 border-white" 
              />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{currentUser.name}</h1>
              <p className="text-blue-200 mt-1">{currentUser.email}</p>
              <p className="text-gray-300 mt-1">Member since {formatDate(currentUser.createdAt)}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-8">
            <div className="mb-8">
              <div className="flex items-center mb-4">
                <Briefcase size={24} className="text-blue-600 mr-2" />
                <h2 className="text-2xl font-bold text-gray-900">My Tasks</h2>
              </div>
              
              {userTasks.length === 0 ? (
                <div className="bg-white rounded-lg shadow-md p-6 text-center">
                  <p className="text-gray-600">You haven't posted any tasks yet.</p>
                  <button
                    onClick={() => window.location.href = '/create-task'}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white font-medium rounded-md shadow-sm hover:bg-blue-700 transition-colors"
                  >
                    Post Your First Task
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userTasks.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              )}
            </div>
            
            <div>
              <div className="flex items-center mb-4">
                <FileText size={24} className="text-blue-600 mr-2" />
                <h2 className="text-2xl font-bold text-gray-900">My Bids</h2>
              </div>
              
              {userBids.length === 0 ? (
                <div className="bg-white rounded-lg shadow-md p-6 text-center">
                  <p className="text-gray-600">You haven't placed any bids yet.</p>
                  <button
                    onClick={() => window.location.href = '/'}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white font-medium rounded-md shadow-sm hover:bg-blue-700 transition-colors"
                  >
                    Browse Tasks
                  </button>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Task
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Bid Amount
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {userBids.map(bid => {
                        const task = getTaskById(bid.taskId);
                        return (
                          <tr key={bid.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <a 
                                href={`/task/${bid.taskId}`}
                                className="text-blue-600 hover:text-blue-800 font-medium"
                              >
                                {task?.title || 'Unknown Task'}
                              </a>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-gray-900 font-medium">
                              ${bid.amount}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                              {formatDate(bid.createdAt)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                {bid.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
          
          <div className="md:col-span-4">
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Account Summary</h3>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Tasks Posted</span>
                  <span className="font-medium text-gray-900">{userTasks.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Bids Placed</span>
                  <span className="font-medium text-gray-900">{userBids.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Bids Accepted</span>
                  <span className="font-medium text-gray-900">
                    {userBids.filter(b => b.status === 'accepted').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tasks Completed</span>
                  <span className="font-medium text-gray-900">
                    {userTasks.filter(t => t.status === 'completed').length}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Edit Profile</h3>
              <button className="w-full px-4 py-2 bg-blue-600 text-white font-medium rounded-md shadow-sm hover:bg-blue-700 transition-colors">
                Update Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProfilePage;